# Face_recognition_v1 > 2025-04-26 10:00pm
https://universe.roboflow.com/facerecognitionv1/face_recognition_v1-xih75

Provided by a Roboflow user
License: CC BY 4.0

